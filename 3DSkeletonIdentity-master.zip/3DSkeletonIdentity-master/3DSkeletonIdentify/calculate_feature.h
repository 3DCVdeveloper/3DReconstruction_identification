#pragma once
#include <string>
#include <queue>
void get_joints_id(std::queue<float *> jointsFrameArray, int frameLen, std::string &id);